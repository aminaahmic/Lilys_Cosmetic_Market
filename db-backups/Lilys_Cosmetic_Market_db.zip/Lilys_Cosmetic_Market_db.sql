CREATE DATABASE Lilys_Cosmetic_Market_db;
GO

USE Lilys_Cosmetic_Market_db;
GO

-- Lookup tables --
CREATE TABLE Currency (
    CurrencyID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    Code NVARCHAR(10) NOT NULL UNIQUE,
    Symbol NVARCHAR(10) NOT NULL,
    Decimals INT NOT NULL DEFAULT 2
);
GO

CREATE TABLE PaymentMethod (
    PaymentMethodID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(50) NOT NULL UNIQUE
);
GO

CREATE TABLE OrderStatus (
    OrderStatusID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(50) NOT NULL UNIQUE
);
GO

CREATE TABLE PaymentStatus (
    PaymentStatusID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(50) NOT NULL UNIQUE
);
GO

CREATE TABLE NotificationType (
    NotificationTypeID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(50) NOT NULL UNIQUE
);
GO

CREATE TABLE Country (
    CountryID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL UNIQUE,
    IsoCode2 NVARCHAR(2) NOT NULL UNIQUE,
    IsoCode3 NVARCHAR(3) NOT NULL UNIQUE,
    CurrencyID INT NOT NULL,
    CONSTRAINT FK_Country_Currency FOREIGN KEY (CurrencyID) REFERENCES Currency(CurrencyID)
);
GO

-- User/Admin --
CREATE TABLE Role (
    RoleID INT PRIMARY KEY IDENTITY(1,1),
    PublicId NVARCHAR(255) UNIQUE NOT NULL,
    Name NVARCHAR(255) NULL
);
GO

CREATE TABLE [User] (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    PublicId NVARCHAR(255) UNIQUE NOT NULL,
    Name NVARCHAR(255) NULL,
    Email NVARCHAR(255) NULL,
    [Password] NVARCHAR(255) NULL,
    RoleID INT NULL,
    Code2FA NVARCHAR(255) NULL,
    ExpiryTime2FA DATETIME NULL,
    TenantID INT NULL,
    CONSTRAINT FK_User_Role FOREIGN KEY (RoleID) REFERENCES Role(RoleID)
);
GO

CREATE TABLE PasswordResetToken (
    TokenID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    Token NVARCHAR(255) UNIQUE NOT NULL,
    ExpiryDate DATETIME NULL,
    Used BIT DEFAULT 0,
    CONSTRAINT FK_PasswordResetToken_User FOREIGN KEY (UserID) REFERENCES [User](UserID)
);
GO

-- Product catalog --
CREATE TABLE Category (
    CategoryID INT PRIMARY KEY IDENTITY(1,1),
    PublicId NVARCHAR(255) UNIQUE NOT NULL,
    Name NVARCHAR(255) NULL
);
GO

CREATE TABLE Subcategory (
    SubcategoryID INT PRIMARY KEY IDENTITY(1,1),
    PublicId NVARCHAR(255) UNIQUE NOT NULL,
    Name NVARCHAR(255) NULL,
    CategoryID INT NULL,
    CONSTRAINT FK_Subcategory_Category FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);
GO

CREATE TABLE Product (
    ProductID INT PRIMARY KEY IDENTITY(1,1),
    PublicId NVARCHAR(255) UNIQUE NOT NULL,
    Name NVARCHAR(255) NULL,
    [Description] NVARCHAR(MAX) NULL,
    SubcategoryID INT NULL,
    CONSTRAINT FK_Product_Subcategory FOREIGN KEY (SubcategoryID) REFERENCES Subcategory(SubcategoryID)
);
GO

CREATE TABLE [Option] (
    OptionID INT PRIMARY KEY IDENTITY(1,1),
    PublicId NVARCHAR(255) UNIQUE NOT NULL,
    Name NVARCHAR(255) NULL
);
GO

CREATE TABLE OptionValue (
    OptionValueID INT PRIMARY KEY IDENTITY(1,1),
    PublicId NVARCHAR(255) UNIQUE NOT NULL,
    OptionID INT NOT NULL,
    [Value] NVARCHAR(255) NULL,
    CONSTRAINT FK_OptionValue_Option FOREIGN KEY (OptionID) REFERENCES [Option](OptionID)
);
GO

CREATE TABLE ProductVariant (
    VariantID INT PRIMARY KEY IDENTITY(1,1),
    PublicId NVARCHAR(255) UNIQUE NOT NULL,
    ProductID INT NOT NULL,
    Price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    Stock INT NOT NULL DEFAULT 0,
    CONSTRAINT FK_ProductVariant_Product FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);
GO

CREATE TABLE VariantOption (
    ID INT PRIMARY KEY IDENTITY(1,1),
    VariantID INT NOT NULL,
    OptionValueID INT NOT NULL,
    CONSTRAINT FK_VariantOption_Variant FOREIGN KEY (VariantID) REFERENCES ProductVariant(VariantID),
    CONSTRAINT FK_VariantOption_OptionValue FOREIGN KEY (OptionValueID) REFERENCES OptionValue(OptionValueID),
    CONSTRAINT UQ_VariantOption_Variant_OptionValue UNIQUE (VariantID, OptionValueID)
);
GO

CREATE TABLE Review (
    ReviewID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    ProductID INT NOT NULL,
    Rating INT NOT NULL CHECK (Rating >= 1 AND Rating <= 5),
    [Comment] NVARCHAR(MAX) NULL,
    CreatedAt DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Review_User FOREIGN KEY (UserID) REFERENCES [User](UserID),
    CONSTRAINT FK_Review_Product FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);
GO

-- Wishlist --
CREATE TABLE Wishlist (
    WishlistID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    Name NVARCHAR(255) NULL,
    CONSTRAINT FK_Wishlist_User FOREIGN KEY (UserID) REFERENCES [User](UserID)
);
GO

CREATE TABLE WishlistProduct (
    ID INT PRIMARY KEY IDENTITY(1,1),
    WishlistID INT NOT NULL,
    ProductID INT NOT NULL,
    CONSTRAINT FK_WishlistProduct_Wishlist FOREIGN KEY (WishlistID) REFERENCES Wishlist(WishlistID),
    CONSTRAINT FK_WishlistProduct_Product FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    CONSTRAINT UQ_WishlistProduct_Wishlist_Product UNIQUE (WishlistID, ProductID)
);
GO

-- Address --
CREATE TABLE [Address] (
    AddressID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    Street NVARCHAR(255) NULL,
    City NVARCHAR(255) NULL,
    PostalCode NVARCHAR(50) NULL,
    CountryID INT NOT NULL,
    CONSTRAINT FK_Address_User FOREIGN KEY (UserID) REFERENCES [User](UserID),
    CONSTRAINT FK_Address_Country FOREIGN KEY (CountryID) REFERENCES Country(CountryID)
);
GO

-- Orders, Cart, Payments, Notifications --
CREATE TABLE [Order] (
    OrderID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    OrderDate DATETIME NOT NULL DEFAULT GETDATE(),
    OrderStatusID INT NOT NULL DEFAULT 1,
    ShippingAddressID INT NULL,
    CONSTRAINT FK_Order_User FOREIGN KEY (UserID) REFERENCES [User](UserID),
    CONSTRAINT FK_Order_OrderStatus FOREIGN KEY (OrderStatusID) REFERENCES OrderStatus(OrderStatusID),
    CONSTRAINT FK_Order_ShippingAddress FOREIGN KEY (ShippingAddressID) REFERENCES [Address](AddressID)
);
GO

CREATE TABLE CartItem (
    ItemID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    VariantID INT NOT NULL,
    Quantity INT NOT NULL DEFAULT 1,
    SavedForLater BIT NOT NULL DEFAULT 0,
    CONSTRAINT FK_CartItem_User FOREIGN KEY (UserID) REFERENCES [User](UserID),
    CONSTRAINT FK_CartItem_Variant FOREIGN KEY (VariantID) REFERENCES ProductVariant(VariantID)
);
GO

CREATE TABLE OrderItem (
    ItemID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT NOT NULL,
    VariantID INT NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    Quantity INT NOT NULL DEFAULT 1,
    CONSTRAINT FK_OrderItem_Order FOREIGN KEY (OrderID) REFERENCES [Order](OrderID),
    CONSTRAINT FK_OrderItem_Variant FOREIGN KEY (VariantID) REFERENCES ProductVariant(VariantID)
);
GO

CREATE TABLE PaymentTransaction (
    TransactionID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT NOT NULL,
    StripeChargeID NVARCHAR(255) UNIQUE NULL,
    Amount DECIMAL(10,2) NOT NULL,
    PaymentStatusID INT NOT NULL DEFAULT 1,
    CurrencyID INT NOT NULL,
    PaymentMethodID INT NOT NULL,
    CreatedAt DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_PaymentTransaction_Order FOREIGN KEY (OrderID) REFERENCES [Order](OrderID),
    CONSTRAINT FK_PaymentTransaction_PaymentStatus FOREIGN KEY (PaymentStatusID) REFERENCES PaymentStatus(PaymentStatusID),
    CONSTRAINT FK_PaymentTransaction_Currency FOREIGN KEY (CurrencyID) REFERENCES Currency(CurrencyID),
    CONSTRAINT FK_PaymentTransaction_PaymentMethod FOREIGN KEY (PaymentMethodID) REFERENCES PaymentMethod(PaymentMethodID)
);
GO

CREATE TABLE Notification (
    NotificationID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    [Content] NVARCHAR(MAX) NULL,
    IsRead BIT NOT NULL DEFAULT 0,
    NotificationTypeID INT NULL,
    CreatedAt DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Notification_User FOREIGN KEY (UserID) REFERENCES [User](UserID),
    CONSTRAINT FK_Notification_Type FOREIGN KEY (NotificationTypeID) REFERENCES NotificationType(NotificationTypeID)
);
GO
-- Seed lookup data --

-- Currency
INSERT INTO Currency (Name, Code, Symbol, Decimals) VALUES
('US Dollar','USD','$',2),
('Euro','EUR','€',2),
('Bosnia and Herzegovina Convertible Mark','BAM','KM',2),
('Croatian Kuna','HRK','kn',2),
('Serbian Dinar','RSD','RSD',2),
('British Pound','GBP','£',2),
('Japanese Yen','JPY','¥',0),
('Swiss Franc','CHF','CHF',2),
('Canadian Dollar','CAD','$',2),
('Australian Dollar','AUD','$',2);
GO

-- PaymentMethod
INSERT INTO PaymentMethod (Name) VALUES
('Credit Card'),
('Debit Card'),
('PayPal'),
('Cash on Delivery'),
('Bank Transfer'),
('Stripe'),
('Apple Pay'),
('Google Pay');
GO

-- OrderStatus
INSERT INTO OrderStatus (Name) VALUES
('Pending'),
('Processing'),
('Shipped'),
('Delivered'),
('Cancelled');
GO

-- PaymentStatus
INSERT INTO PaymentStatus (Name) VALUES
('Pending'),
('Paid'),
('Failed'),
('Refunded');
GO

-- NotificationType
INSERT INTO NotificationType (Name) VALUES
('Info'),
('Warning'),
('System'),
('Marketing');
GO

-- Country
-- Pretpostavlja se da CurrencyID odgovara redoslijedu unosa (1-10)
INSERT INTO Country (Name, IsoCode2, IsoCode3, CurrencyID) VALUES
('Bosnia and Herzegovina','BA','BIH',3),
('Croatia','HR','HRV',4),
('Serbia','RS','SRB',5),
('Germany','DE','DEU',2),
('United States','US','USA',1),
('United Kingdom','GB','GBR',6),
('Japan','JP','JPN',7),
('Switzerland','CH','CHE',8),
('Canada','CA','CAN',9),
('Australia','AU','AUS',10);
GO
